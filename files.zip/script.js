<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scam Awareness Educational Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <header class="header">
            <div class="header-content">
                <h1>🛡️ Scam Awareness Form</h1>
                <p class="subtitle">Educational Resource - Understanding Common Scam Patterns</p>
            </div>
        </header>

        <!-- Main Form Container -->
        <main class="form-container">
            <form id="scamAwarenessForm" class="form">
                <!-- Section 1: Personal Background -->
                <section class="form-section">
                    <h2 class="section-title">📋 Personal Background Information</h2>
                    
                    <div class="form-group">
                        <label for="age">What is your age range?</label>
                        <select id="age" name="age" required>
                            <option value="">Select age range</option>
                            <option value="18-25">18-25</option>
                            <option value="26-35">26-35</option>
                            <option value="36-45">36-45</option>
                            <option value="46-55">46-55</option>
                            <option value="56+">56+</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="profession">What is your profession/occupation?</label>
                        <input type="text" id="profession" name="profession" placeholder="e.g., Student, Engineer, Business Owner" required>
                    </div>

                    <div class="form-group">
                        <label for="experience">How tech-savvy would you rate yourself?</label>
                        <select id="experience" name="experience" required>
                            <option value="">Select experience level</option>
                            <option value="beginner">Beginner</option>
                            <option value="intermediate">Intermediate</option>
                            <option value="advanced">Advanced</option>
                        </select>
                    </div>
                </section>

                <!-- Section 2: How You Met -->
                <section class="form-section">
                    <h2 class="section-title">👥 How Did You Meet?</h2>
                    
                    <div class="form-group">
                        <label for="meetPlatform">Which platform did you meet on?</label>
                        <select id="meetPlatform" name="meetPlatform" required>
                            <option value="">Select platform</option>
                            <option value="dating-app">Dating App (Tinder, Bumble, etc.)</option>
                            <option value="social-media">Social Media (Facebook, Instagram, etc.)</option>
                            <option value="crypto-discord">Cryptocurrency Discord/Telegram</option>
                            <option value="investment-group">Investment Group/Forum</option>
                            <option value="other-social">Other Social Platform</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="initialContact">What was the initial approach like?</label>
                        <textarea id="initialContact" name="initialContact" placeholder="Describe how they first contacted you..." rows="4"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="connectionSpeed">How quickly did the relationship develop?</label>
                        <select id="connectionSpeed" name="connectionSpeed" required>
                            <option value="">Select timeline</option>
                            <option value="very-quick">Very quickly (within days)</option>
                            <option value="quick">Quick (within 1-2 weeks)</option>
                            <option value="moderate">Moderate (within a month)</option>
                            <option value="slow">Slow (gradual development)</option>
                        </select>
                    </div>
                </section>

                <!-- Section 3: Scammer Details -->
                <section class="form-section">
                    <h2 class="section-title">🔍 Details About the Scammer</h2>
                    
                    <div class="form-group">
                        <label for="scammerProfile">What was their profile like? (without personal identifiable info)</label>
                        <textarea id="scammerProfile" name="scammerProfile" placeholder="e.g., Claimed to be a successful entrepreneur, military personnel, doctor, etc..." rows="4"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="redFlags">Did you notice any red flags? (Select all that apply)</label>
                        <div class="checkbox-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="unclear-photos">
                                Unclear or stock photos
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="avoiding-video">
                                Avoiding video calls
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="moving-platform">
                                Quickly moving to private messaging
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="perfect-story">
                                Too perfect/romantic story
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="money-talk">
                                Talking about money quickly
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="grammar-issues">
                                Poor grammar/language issues
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="redFlags" value="none-noticed">
                                Didn't notice any at first
                            </label>
                        </div>
                    </div>
                </section>

                <!-- Section 4: Money/Crypto Details -->
                <section class="form-section">
                    <h2 class="section-title">💰 Financial Information</h2>
                    
                    <div class="form-group">
                        <label for="fraudType">What type of fraud occurred?</label>
                        <select id="fraudType" name="fraudType" required>
                            <option value="">Select fraud type</option>
                            <option value="romance">Romance Scam</option>
                            <option value="crypto">Cryptocurrency Fraud</option>
                            <option value="gold">Gold/Precious Metals</option>
                            <option value="forex">Forex/Trading</option>
                            <option value="investment">Investment Scheme</option>
                            <option value="loan">Loan Scam</option>
                            <option value="combined">Multiple types</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="platform">Which platform(s) is your money stuck on?</label>
                        <select id="platform" name="platform" required>
                            <option value="">Select platform</option>
                            <option value="crypto-exchange">Cryptocurrency Exchange (Binance, Coinbase, etc.)</option>
                            <option value="crypto-wallet">Crypto Wallet (MetaMask, Trust Wallet, etc.)</option>
                            <option value="bank-transfer">Bank Transfer</option>
                            <option value="wire-transfer">Wire Transfer</option>
                            <option value="gift-card">Gift Cards</option>
                            <option value="money-transfer">Money Transfer Service (Western Union, etc.)</option>
                            <option value="forex-broker">Forex Broker Platform</option>
                            <option value="investment-platform">Investment Platform</option>
                            <option value="multiple">Multiple platforms</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="amountRange">What is the approximate amount (select range)?</label>
                        <select id="amountRange" name="amountRange" required>
                            <option value="">Select range</option>
                            <option value="under-1000">Under $1,000</option>
                            <option value="1000-5000">$1,000 - $5,000</option>
                            <option value="5000-10000">$5,000 - $10,000</option>
                            <option value="10000-50000">$10,000 - $50,000</option>
                            <option value="50000-100000">$50,000 - $100,000</option>
                            <option value="100000-plus">$100,000+</option>
                        </select>
                    </div>
                </section>

                <!-- Section 5: Duration & Status -->
                <section class="form-section">
                    <h2 class="section-title">⏰ Timeline & Current Status</h2>
                    
                    <div class="form-group">
                        <label for="howLong">How long have you been in contact with this person?</label>
                        <select id="howLong" name="howLong" required>
                            <option value="">Select duration</option>
                            <option value="less-than-month">Less than 1 month</option>
                            <option value="1-3-months">1-3 months</option>
                            <option value="3-6-months">3-6 months</option>
                            <option value="6-12-months">6-12 months</option>
                            <option value="1-2-years">1-2 years</option>
                            <option value="2-plus-years">2+ years</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="currentStatus">Are you still in contact with them?</label>
                        <div class="radio-group">
                            <label class="radio-label">
                                <input type="radio" name="currentStatus" value="yes-active" required>
                                Yes, still actively talking
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="currentStatus" value="yes-minimal">
                                Yes, but minimal contact
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="currentStatus" value="no-blocked">
                                No, I blocked them
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="currentStatus" value="no-ghosted">
                                No, they disappeared
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="lastContact">When was your last contact?</label>
                        <input type="date" id="lastContact" name="lastContact" required>
                    </div>
                </section>

                <!-- Section 6: Additional Information -->
                <section class="form-section">
                    <h2 class="section-title">📝 Additional Details</h2>
                    
                    <div class="form-group">
                        <label for="attempts">How many times did they ask for money/investment?</label>
                        <select id="attempts" name="attempts" required>
                            <option value="">Select option</option>
                            <option value="once">Once</option>
                            <option value="few-times">A few times</option>
                            <option value="multiple">Multiple times</option>
                            <option value="continuous">Continuously</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="hopeRecovery">Do you still hope to recover your money?</label>
                        <select id="hopeRecovery" name="hopeRecovery" required>
                            <option value="">Select option</option>
                            <option value="yes-hopeful">Yes, very hopeful</option>
                            <option value="somewhat">Somewhat hopeful</option>
                            <option value="not-really">Not really</option>
                            <option value="no-accepted">No, accepted the loss</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="additionalInfo">Any additional information you'd like to share?</label>
                        <textarea id="additionalInfo" name="additionalInfo" placeholder="Share any other relevant details..." rows="4"></textarea>
                    </div>

                    <div class="form-group checkbox">
                        <label class="checkbox-label">
                            <input type="checkbox" id="consent" name="consent" required>
                            I understand this is for educational purposes only
                        </label>
                    </div>
                </section>

                <!-- Submit Button -->
                <div class="form-actions">
                    <button type="submit" class="btn-primary">Submit Form</button>
                    <button type="reset" class="btn-secondary">Clear Form</button>
                </div>
            </form>

            <!-- Success Message -->
            <div id="successMessage" class="success-message">
                <h3>✓ Form Submitted Successfully
